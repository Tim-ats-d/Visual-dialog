#!/usr/bin/env python3

"""
A librairie which provides class and functions to make easier dialog box in terminal.
"""

__version__ = 0.6

from .core import DialogBox
